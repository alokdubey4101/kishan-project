$(document).ready(function ()
{
    $('.dob').datepicker({
        dateFormat: 'mm-dd-yy'
    });
    $('.but').click(function () {
        var name = $('.name').val();
        var pass = $('.pass').val();
        var cpass = $('.cpass').val();
        var add = $('.add').val();
        var dob = $('.dob').val();
        $('.but').hide();
        $('.rol').html("<img src='roller/roller.gif'>");
        if (name.trim() === '' && pass.trim() === '' && cpass.trim() === '' && add.trim() === '' && dob === '') {
            $('.check').css('color', 'red');
            $('.check').html('please Enter any detail you want update');
            $('.but').show();
            $('.rol').html('');
        } else if (pass.trim() !== '')
        {
            if (cpass.trim() === '' || cpass !== pass)
            {
                $('.check').css('color', 'red');
                $('.check').html('please fill correctly confirm password');
                $('.but').show();
                $('.rol').html('');
            } else {
                $.ajax({
                    type: 'POST',
                    url: 'Update',
                    data: {name: name, pass: pass, add: add, dob: dob},
                    success: function (data) {
                        var op = JSON.parse(data);
                        if (op.done === 'yes') {
                            $('.but').show();
                            $('.rol').html('');
                            $('.check').css('color', 'green');
                            $('.check').html('The value successfuly update');
                        }
                    }
                });
            }
        } else {
            $.ajax({
                type: 'POST',
                url: 'Update',
                data: {name: name, pass: pass, add: add, dob: dob},
                success: function (data) {
                    var op = JSON.parse(data);
                    if (op.done === 'yes') {
                        $('.but').show();
                        $('.rol').html('');
                        $('.check').css('color', 'green');
                        $('.check').html('The value successfuly update');
                    }
                }
            });
        }

    });
});