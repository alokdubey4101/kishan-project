$(document).on('click', '.but',function(){
    var email = $('.email').val();
    var password = $('.password').val();
    $('.but').hide();
    $('.rol').html('<img src=\"roller/roller.gif\"/>');
    if (email.trim() === '')
    {
        $('.emailspan').css('color', 'red');
        $('.email').css('border-color', 'red');
        $('.emailspan').html('Enter The Email');
        $('.password').css('border-color', '');
        $('.passwordspan').html('');
        $('.but').show();
        $('.rol').html('');
    } else if (password.trim() === '')
    {
        $('.password').css('border-color', 'red');
        $('.passwordspan').css('color', 'red');
        $('.passwordspan').html('Enter The Password');
        $('.email').css('border-color', '');
        $('.emailspan').html('');
        $('.but').show();
        $('.rol').html('');
    } else
    {
        $('.password').css('border-color', '');
        $('.passwordspan').css('color', '');
        $('.passwordspan').html('');
        $('.email').css('border-color', '');
        $('.emailspan').html('');
        $.ajax({
            type: 'POST',
            url: 'Alogin',
            data: {email: email, password: password},
            success: function (result) {
                var op = JSON.parse(result);
                if (op.done === 'no')
                {
                    $('.emailspan').css('color', 'red');
                    $('.email').css('border-color', 'red');
                    $('.emailspan').html('Sorry the E-mail is not registered');
                    $('.password').css('border-color', '');
                    $('.passwordspan').html('');
                    $('.but').show();
                    $('.rol').html('');
                }
                else if (op.done === 'not')
                {
                    $('.password').css('border-color', 'red');
                    $('.passwordspan').css('color', 'red');
                    $('.passwordspan').html('The password is incorrect');
                    $('.email').css('border-color', '');
                    $('.emailspan').html('');
                    $('.but').show();
                    $('.rol').html('');
                }
                else if (op.done === 'yes')
                {
                    $('.but').show();
                    $('.rol').html('');
                    $(location).attr('href', 'admin_home.jsp');
                }
            }
        });
    }
});