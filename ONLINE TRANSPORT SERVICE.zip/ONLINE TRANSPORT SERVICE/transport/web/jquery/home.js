$(document).ready(function(){
        $('.panel').accordion();
        //#4CAF50
});