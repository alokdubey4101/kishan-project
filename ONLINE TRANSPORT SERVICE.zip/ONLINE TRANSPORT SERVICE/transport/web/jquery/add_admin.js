$(document).ready(function () {
    $('.but').click(function () {
        var name = $('.name').val();
        var email = $('.email').val();
        var phone = $('.phone').val();
        var branch = $('.branch').val();
        $('.but').hide();
        $('.rol').html('<img src=\"roller/roller.gif\"/>');
        if (name === '') {
            $('.name').css('border-color', 'red');
            $('.namespan').css('color', 'red');
            $('.namespan').html('Enter the name');
            $('.emailspan').html('');
            $('.phonespan').html('');
            $('.branchspan').html('');
            $('.email').css('border-color', '');
            $('.branch').css('border-color', '');
            $('.phone').css('border-color', '');
            $('.but').show();
            $('.rol').html('');
        } else if (email === '') {
            $('.email').css('border-color', 'red');
            $('.emailspan').css('color', 'red');
            $('.emailspan').html('Enter the name');
            $('.namespan').html('');
            $('.phonespan').html('');
            $('.branchspan').html('');
            $('.name').css('border-color', '');
            $('.branch').css('border-color', '');
            $('.phone').css('border-color', '');
            $('.but').show();
            $('.rol').html('');
        } else if (phone === '') {
            $('.phone').css('border-color', 'red');
            $('.phonespan').css('color', 'red');
            $('.phonespan').html('Enter the name');
            $('.emailspan').html('');
            $('.namespan').html('');
            $('.branchspan').html('');
            $('.email').css('border-color', '');
            $('.branch').css('border-color', '');
            $('.name').css('border-color', '');
            $('.but').show();
            $('.rol').html('');
        } else if (branch === '-----select choice-----') {
            $('.branch').css('border-color', 'red');
            $('.branchspan').css('color', 'red');
            $('.branchspan').html('Enter the name');
            $('.emailspan').html('');
            $('.phonespan').html('');
            $('.namespan').html('');
            $('.phone').css('border-color', '');
            $('.email').css('border-color', '');
            $('.name').css('border-color', '');
            $('.but').show();
            $('.rol').html('');
        } else {
            $('.branch').css('border-color', '');
            $('.branchspan').css('color', '');
            $('.branchspan').html('');
            $('.emailspan').html('');
            $('.phonespan').html('');
            $('.namespan').html('');
            $('.phone').css('border-color', '');
            $('.branch').css('border-color', '');
            $('.name').css('border-color', '');
            $.ajax({
                url: 'add_admin',
                type: 'post',
                data: {name: name, email: email, phone: phone, branch: branch},
                success: function (result) {
                    var op = JSON.parse(result);
                    if (op.done === 'yes') {
                        $('.result').css('color', 'green');
                        $('.result').html('Please note the admin\'s password is: ' + op.password);
                        $('.but').show();
                        $('.rol').html('');
                    }
                    if(op.done==='no'){
                        $('.result').css('color', 'red');
                        $('.result').html('Email is already present');
                        $('.but').show();
                        $('.rol').html('');
                    }
                }
            });
        }
    });
});