package com.normal;

import java.util.ArrayList;
import java.util.List;
import java.sql.*;

public class fCity {
    public List<String> city;
    
    public fCity(){
        city=new ArrayList<>();
    }
    
    public List<String> fetch(){
        try{
            Connect co=new Connect();
            Connection con=co.db();
            PreparedStatement ps=con.prepareStatement("select * from cities");
            ResultSet rs=ps.executeQuery();
            while(rs.next()){
                city.add(rs.getString("city"));
            }
        }catch(Exception e){System.out.println("fCity.java: "+e);}
        return city;
    }
}
