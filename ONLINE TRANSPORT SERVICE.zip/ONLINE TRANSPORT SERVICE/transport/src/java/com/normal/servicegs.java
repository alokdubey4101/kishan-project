package com.normal;

public class servicegs {
    public static int id=0;
    public static String subcity="";
    public void setId(int id){
        servicegs.id=id;
    }
    public int getId(){
        return servicegs.id;
    }
    public void setSubCity(String subcity){
        servicegs.subcity=subcity;
    }
    
    public String getSubCity(){
        return servicegs.subcity;
    }
    
}
