package com.normal;

import java.sql.*;

public class Fbook {
    public static String email="";
    public void db(String email){
        try{
            Connect co=new Connect();
            Connection con=co.db();
            PreparedStatement ps=con.prepareStatement("select * from book where email=?");
            ps.setString(1, email);
            ResultSet rs=ps.executeQuery();
            while(rs.next()){
                Fbook.email=rs.getString("email");
            }
            rs.close();
            ps.close();
            rs.close();
        }
        catch(SQLException e){
            System.out.println("Fbook.java: "+e);
        }
    }
    public String getEmail(){
        return Fbook.email;
    }
}
