package com.normal;

import java.sql.*;

public class Trucks {
    public void available(){
        try{
            Connect co=new Connect();
            Connection con=co.db();
            PreparedStatement ps=con.prepareStatement("update truck set available=available+1");
            int id=ps.executeUpdate();
            ps.close();
            con.close();
        }catch(Exception e){
            System.out.println("Trucks.java: "+e);
        }
    }
    public void current(){
        try{
            Connect co=new Connect();
            Connection con=co.db();
            PreparedStatement ps=con.prepareStatement("update truck set current=current+1");
            int id=ps.executeUpdate();
            ps.close();
            con.close();
        }catch(Exception e){
            System.out.println("Trucks.java: "+e);
        }
    }
    public void booked(){
        try{
            Connect co=new Connect();
            Connection con=co.db();
            PreparedStatement ps=con.prepareStatement("update truck set booked=booked+1");
            int id=ps.executeUpdate();
            ps.close();
            con.close();
        }catch(Exception e){
            System.out.println("Trucks.java: "+e);
        }
    }
    public void dcurrent(){
        try{
            Connect co=new Connect();
            Connection con=co.db();
            PreparedStatement ps=con.prepareStatement("update truck set current=current-1");
            int id=ps.executeUpdate();
            ps.close();
            con.close();
        }catch(Exception e){
            System.out.println("Trucks.java: "+e);
        }
    }
    public void dbooked(){
        try{
            Connect co=new Connect();
            Connection con=co.db();
            PreparedStatement ps=con.prepareStatement("update truck set booked=booked-1");
            int id=ps.executeUpdate();
            ps.close();
            con.close();
        }catch(Exception e){
            System.out.println("Trucks.java: "+e);
        }
    }
    public void davailable(){
        try{
            Connect co=new Connect();
            Connection con=co.db();
            PreparedStatement ps=con.prepareStatement("update truck set available=available-1");
            int id=ps.executeUpdate();
            ps.close();
            con.close();
        }catch(Exception e){
            System.out.println("Trucks.java: "+e);
        }
    }
}
