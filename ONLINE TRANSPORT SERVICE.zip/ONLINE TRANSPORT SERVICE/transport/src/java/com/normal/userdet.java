package com.normal;

import java.sql.*;

public class userdet {
    public static int id=0;
    public static String name="";
    public void db(String email){
        try{
            Connect co=new Connect();
            Connection con=co.db();
            PreparedStatement ps=con.prepareStatement("select * from register where email=?");
            ps.setString(1, email);
            ResultSet rs=ps.executeQuery();
            while(rs.next()){
                id=rs.getInt("user_id");
                name=rs.getString("name");
            }
        }catch(Exception e){System.out.println("userdet.java: "+e);}
    }
    public int getId(){
        return userdet.id;
    }
    public String getName(){
        return userdet.name;
    }
}
