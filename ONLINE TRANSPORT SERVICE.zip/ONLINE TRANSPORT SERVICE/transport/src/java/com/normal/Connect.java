package com.normal;

import java.sql.*;


public class Connect{
    public Connection db() throws SQLException{
        try{
            Class.forName("com.mysql.jdbc.Driver");
        }catch(ClassNotFoundException e){System.out.println("Connect.java: "+e);}
        return DriverManager.getConnection("jdbc:mysql://localhost:3307/transport?useSSL=false", "root", "1234");
    }
}
