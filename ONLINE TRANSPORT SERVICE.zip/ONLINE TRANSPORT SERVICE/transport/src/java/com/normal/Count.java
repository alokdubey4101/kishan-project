package com.normal;

import java.sql.*;

public class Count {    
    public void available(String subcity){
        try{
            Connect co=new Connect();
            Connection con=co.db();
            PreparedStatement ps=con.prepareStatement("update counts set available=available+1 where subcity=?");
            ps.setString(1, subcity);
            int id=ps.executeUpdate();
            ps.close();
            con.close();
        }
        catch(Exception e){
            System.out.println("Count.java: "+e);
        }
    }
    public void current(String subcity){
        try{
            Connect co=new Connect();
            Connection con=co.db();
            PreparedStatement ps=con.prepareStatement("update counts set current=current+1 where subcity=?");
            ps.setString(1, subcity);
            int id=ps.executeUpdate();
            ps.close();
            con.close();
        }
        catch(Exception e){
            System.out.println("Count.java: "+e);
        }
    }
    public void booked(String subcity){
        try{
            Connect co=new Connect();
            Connection con=co.db();
            PreparedStatement ps=con.prepareStatement("update counts set booked=booked+1 where subcity=?");
            ps.setString(1, subcity);
            int id=ps.executeUpdate();
            ps.close();
            con.close();
        }
        catch(Exception e){
            System.out.println("Count.java: "+e);
        }
    }
    public void all(String subcity){
        try{
            Connect co=new Connect();
            Connection con=co.db();
            PreparedStatement ps1=con.prepareStatement("update counts set available=available+1 where subcity=?");
            PreparedStatement ps2=con.prepareStatement("update counts set current=current+1 where subcity=?");
            PreparedStatement ps3=con.prepareStatement("update counts set booked=booked+1 where subcity=?");
            ps1.setString(1, subcity);
            ps2.setString(1, subcity);
            ps3.setString(1, subcity);
            int id1=ps1.executeUpdate();
            int id2=ps2.executeUpdate();
            int id3=ps3.executeUpdate();
            ps1.close();
            ps2.close();
            ps3.close();
            con.close();
        }
        catch(Exception e){
            System.out.println("Count.java: "+e);
        }
    }
    public void davailable(String subcity){
        try{
            Connect co=new Connect();
            Connection con=co.db();
            PreparedStatement ps=con.prepareStatement("update counts set available=available-1 where subcity=?");
            ps.setString(1, subcity);
            int id=ps.executeUpdate();
            ps.close();
            con.close();
        }
        catch(Exception e){
            System.out.println("Count.java: "+e);
        }
    }
    public void dcurrent(String subcity){
        try{
            Connect co=new Connect();
            Connection con=co.db();
            PreparedStatement ps=con.prepareStatement("update counts set current=current-1 where subcity=?");
            ps.setString(1, subcity);
            int id=ps.executeUpdate();
            ps.close();
            con.close();
        }
        catch(Exception e){
            System.out.println("Count.java: "+e);
        }
    }
    public void dbooked(String subcity){
        try{
            Connect co=new Connect();
            Connection con=co.db();
            PreparedStatement ps=con.prepareStatement("update counts set booked=booked-1 where subcity=?");
            ps.setString(1, subcity);
            int id=ps.executeUpdate();
            ps.close();
            con.close();
        }
        catch(Exception e){
            System.out.println("Count.java: "+e);
        }
    }
    public void dall(String subcity){
        try{
            Connect co=new Connect();
            Connection con=co.db();
            PreparedStatement ps1=con.prepareStatement("update counts set available=available-1 where subcity=?");
            PreparedStatement ps2=con.prepareStatement("update counts set current=current-1 where subcity=?");
            PreparedStatement ps3=con.prepareStatement("update counts set booked=booked-1 where subcity=?");
            ps1.setString(1, subcity);
            ps2.setString(1, subcity);
            ps3.setString(1, subcity);
            int id1=ps1.executeUpdate();
            int id2=ps2.executeUpdate();
            int id3=ps3.executeUpdate();
            ps1.close();
            ps2.close();
            ps3.close();
            con.close();
        }
        catch(Exception e){
            System.out.println("Count.java: "+e);
        }
    }
    public void availableid(int ids){
        try{
            Connect co=new Connect();
            Connection con=co.db();
            PreparedStatement ps=con.prepareStatement("update counts set available=available+1 where ids=?");
            ps.setInt(1, ids);
            int id=ps.executeUpdate();
            ps.close();
            con.close();
        }
        catch(Exception e){
            System.out.println("Count.java: "+e);
        }
    }
    public void currentid(int ids){
        try{
            Connect co=new Connect();
            Connection con=co.db();
            PreparedStatement ps=con.prepareStatement("update counts set current=current+1 where id=?");
            ps.setInt(1, ids);
            int id=ps.executeUpdate();
            ps.close();
            con.close();
        }
        catch(Exception e){
            System.out.println("Count.java: "+e);
        }
    }
    public void bookedid(int ids){
        try{
            Connect co=new Connect();
            Connection con=co.db();
            PreparedStatement ps=con.prepareStatement("update counts set booked=booked+1 where id=?");
            ps.setInt(1, ids);
            int id=ps.executeUpdate();
            ps.close();
            con.close();
        }
        catch(Exception e){
            System.out.println("Count.java: "+e);
        }
    }
    public void allid(int ids){
        try{
            Connect co=new Connect();
            Connection con=co.db();
            PreparedStatement ps1=con.prepareStatement("update counts set available=available+1 where id=?");
            PreparedStatement ps2=con.prepareStatement("update counts set current=current+1 where id=?");
            PreparedStatement ps3=con.prepareStatement("update counts set booked=booked+1 where id=?");
            ps1.setInt(1, ids);
            ps2.setInt(1, ids);
            ps3.setInt(1, ids);
            int id1=ps1.executeUpdate();
            int id2=ps2.executeUpdate();
            int id3=ps3.executeUpdate();
            ps1.close();
            ps2.close();
            ps3.close();
            con.close();
        }
        catch(Exception e){
            System.out.println("Count.java: "+e);
        }
    }
    public void davailableid(int ids){
        try{
            Connect co=new Connect();
            Connection con=co.db();
            PreparedStatement ps=con.prepareStatement("update counts set available=available-1 where ids=?");
            ps.setInt(1, ids);
            int id=ps.executeUpdate();
            ps.close();
            con.close();
        }
        catch(Exception e){
            System.out.println("Count.java: "+e);
        }
    }
    public void dcurrentid(int ids){
        try{
            Connect co=new Connect();
            Connection con=co.db();
            PreparedStatement ps=con.prepareStatement("update counts set current=current-1 where id=?");
            ps.setInt(1, ids);
            int id=ps.executeUpdate();
            ps.close();
            con.close();
        }
        catch(Exception e){
            System.out.println("Count.java: "+e);
        }
    }
    public void dbookedid(int ids){
        try{
            Connect co=new Connect();
            Connection con=co.db();
            PreparedStatement ps=con.prepareStatement("update counts set booked=booked-1 where id=?");
            ps.setInt(1, ids);
            int id=ps.executeUpdate();
            ps.close();
            con.close();
        }
        catch(Exception e){
            System.out.println("Count.java: "+e);
        }
    }
    public void dall(int ids){
        try{
            Connect co=new Connect();
            Connection con=co.db();
            PreparedStatement ps1=con.prepareStatement("update counts set available=available-1 where id=?");
            PreparedStatement ps2=con.prepareStatement("update counts set current=current-1 where id=?");
            PreparedStatement ps3=con.prepareStatement("update counts set booked=booked-1 where id=?");
            ps1.setInt(1, ids);
            ps2.setInt(1, ids);
            ps3.setInt(1, ids);
            int id1=ps1.executeUpdate();
            int id2=ps2.executeUpdate();
            int id3=ps3.executeUpdate();
            ps1.close();
            ps2.close();
            ps3.close();
            con.close();
        }
        catch(Exception e){
            System.out.println("Count.java: "+e);
        }
    }
}
