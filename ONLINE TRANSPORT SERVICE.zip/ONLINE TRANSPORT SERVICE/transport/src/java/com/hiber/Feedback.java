package com.hiber;

public class Feedback implements java.io.Serializable{
    private Integer id;
    private String name;
    private String email;
    private String message;
    
    public Feedback(){
    }
    
    public Feedback(String name, String email, String message){
        this.name=name;
        this.email=email;
        this.message=message;
    }
    
    public void setId(Integer id){
        this.id=id;
    }
    public Integer getId(){
        return this.id;
    }
    
    public void setName(String name){
        this.name=name;
    }
    public String getName(){
        return this.name;
    }
    
    public void setEmail(String email){
        this.email=email;
    }
    public String getEmail(){
        return this.email;
    }
    
    public void setMessage(String message){
        this.message=message;
    }
    public String getMessage(){
        return this.message;
    }
}
