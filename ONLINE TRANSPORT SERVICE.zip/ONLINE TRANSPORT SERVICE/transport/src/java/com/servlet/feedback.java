package com.servlet;

import com.hiber.Feedback;
import com.normal.Fbook;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class feedback extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException{
        PrintWriter out=response.getWriter();
        HttpSession session=request.getSession();
        String name=request.getParameter("name");
        String msg=request.getParameter("msg");
        String email=session.getAttribute("email").toString();
        if(name.trim().equals("") || msg.trim().equals("")){
            out.println("<html>");
            out.println("<head>");
            out.println("</head>");
            out.println("<body>");
            out.println("<script>");
            out.println("alert('sorry for interrupting none of the field should be empty');");
            out.println("</script>");
            out.println("</body>");
            out.println("</html>");
            RequestDispatcher rd=request.getRequestDispatcher("user_feedback.jsp");
            rd.include(request, response);
        }
        else{
            try{
                Feedback fe=new Feedback(name, email, msg);
                SessionFactory sf=new Configuration().configure().buildSessionFactory();
                Session ses=sf.openSession();
                Transaction tran=ses.beginTransaction();
                ses.save(fe);
                tran.commit();
                ses.close();
                sf.close();
                RequestDispatcher rd=request.getRequestDispatcher("user_feedback.jsp");
                rd.include(request, response);
            }catch(Exception e){
                System.out.println("feedback.java: "+e);
            }
        }
    }
}
