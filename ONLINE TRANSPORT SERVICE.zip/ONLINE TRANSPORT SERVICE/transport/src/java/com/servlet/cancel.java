package com.servlet;

import com.normal.Connect;
import com.normal.Count;
import com.normal.Trucks;
import java.io.IOException;
import java.sql.*;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class cancel extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException{
        int id=Integer.parseInt(request.getParameter("id"));
        String subcity=request.getParameter("subcity");
        try{
            Connect co=new Connect();
            Connection con=co.db();
            PreparedStatement ps1 = con.prepareStatement("update book set date_at_want='none' where book_id=?");
            ps1.setInt(1, id);
            PreparedStatement ps2 = con.prepareStatement("update book set dateofbook='none' where book_id=?");
            ps2.setInt(1, id);
            PreparedStatement ps3 = con.prepareStatement("update book set email='none' where book_id=?");
            ps3.setInt(1, id);
            PreparedStatement ps4 = con.prepareStatement("update book set bornb='not booked' where book_id=?");
            ps4.setInt(1, id);
            PreparedStatement ps5 = con.prepareStatement("update book set datemili='none' where book_id=?");
            ps5.setInt(1, id);
            PreparedStatement ps6 = con.prepareStatement("update book set address='none' where book_id=?");
            ps6.setInt(1, id);
            PreparedStatement ps7 = con.prepareStatement("update book set quantity='none' where book_id=?");
            ps7.setInt(1, id);
            PreparedStatement ps8 = con.prepareStatement("update book set date_at_wantmili='none' where book_id=?");
            ps8.setInt(1, id);
            PreparedStatement ps9 = con.prepareStatement("update book set time_at_want='none' where book_id=?");
            ps9.setInt(1, id);
            PreparedStatement ps10 = con.prepareStatement("update book set address_at_want='none' where book_id=?");
            ps10.setInt(1, id);
            PreparedStatement ps11 = con.prepareStatement("update book set user_id=? where book_id=?");
            ps11.setInt(1, 0);
            ps11.setInt(2, id);
            int ids1 = ps1.executeUpdate();
            int ids2 = ps2.executeUpdate();
            int ids3 = ps3.executeUpdate();
            int ids4 = ps4.executeUpdate();
            int ids5 = ps5.executeUpdate();
            int ids6 = ps6.executeUpdate();
            int ids7 = ps7.executeUpdate();
            int ids8 = ps8.executeUpdate();
            int ids9 = ps9.executeUpdate();
            int ids10 = ps10.executeUpdate();
            int ids11 = ps11.executeUpdate();
            if(ids1==1 && ids2==1 && ids3==1 && ids4==1 && ids5==1 && ids6==1 && ids7==1 && ids8==1 && ids9==1 && ids10==1 && ids11==1)
            {
                response.sendRedirect("home.jsp");
            }
            ps1.close();
            ps2.close();
            ps3.close();
            ps4.close();
            ps5.close();
            ps6.close();
            ps7.close();
            ps8.close();
            ps9.close();
            ps10.close();
            ps11.close();
            con.close();
            Trucks tr=new Trucks();
            Count cou=new Count();
            cou.dbooked(subcity);
            cou.current(subcity);
            tr.dbooked();
            tr.current();
        }catch(SQLException e){System.out.println("cancel.java: "+e);}
    }
}
