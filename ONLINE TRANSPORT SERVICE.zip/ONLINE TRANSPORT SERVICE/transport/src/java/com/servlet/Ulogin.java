package com.servlet;

import java.sql.*;
import com.google.gson.JsonObject;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class Ulogin extends HttpServlet {
    public static String femail="";
    public static String fpassword="";
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException
    {
        HttpSession session=request.getSession();
        PrintWriter out=response.getWriter();
        JsonObject jo=new JsonObject();
        String email=request.getParameter("email");
        String password=request.getParameter("password");
        db(email);
        String remail=cemail();
        String rpassword=cpassword();
        if(!remail.equals(email))
        {
            jo.addProperty("done", "no");
            out.println(jo);
        }
        else if(!rpassword.equals(password))
        {
            jo.addProperty("done", "not");
            out.println(jo);
        }
        else 
        {
            session.setAttribute("email", email);
            jo.addProperty("done", "yes");
            out.println(jo);
        }
    }
    public void db(String email)
    {
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3307/transport?useSSL=false", "root", "1234");
            PreparedStatement ps=con.prepareStatement("select * from register where email=?");
            ps.setString(1, email);
            ResultSet rs=ps.executeQuery();
            while(rs.next())
            {
                femail=rs.getString("email");
                fpassword=rs.getString("password");
            }
            rs.close();
            ps.close();
            con.close();
        }
        catch(Exception e)
        {
            System.out.println("login.java: "+e);
        }
    }
    public String cemail()
    {
        return Ulogin.femail;
    }
    public String cpassword()
    {
        return Ulogin.fpassword;
    }
}
