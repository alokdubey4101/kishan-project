package com.servlet;

import com.google.gson.JsonObject;
import com.hiber.Register;
import java.sql.*;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Usignup extends HttpServlet {
    public static String femail="";
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException
    {
        JsonObject jo=new JsonObject();
        PrintWriter out=response.getWriter();
        String name=request.getParameter("name");
        String email=request.getParameter("email");
        String password=request.getParameter("password");
        String add=request.getParameter("add");
        String dob=request.getParameter("dob");
        db(email);
        String lemail=cemail();
        if(email.equals(lemail))
        {
            jo.addProperty("done", "no");
            out.println(jo);
        }
        else
        {
            try
            {
                SessionFactory sef = new Configuration().configure().buildSessionFactory();
                Session ses = sef.openSession();
                Register re = new Register(name, email, password, add, dob);
                ses.save(re);
                Transaction tran = ses.beginTransaction();
                tran.commit();
                ses.close();
            }
            catch(HibernateException e)
            {
                System.out.println("Usignup.java: "+e);
            }
            jo.addProperty("done", "yes");
            out.println(jo);
        }
    }
    public void db(String email)
    {
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3307/transport?useSSL=false", "root", "1234");
            PreparedStatement ps=con.prepareStatement("select * from register where email=?");
            ps.setString(1, email);
            ResultSet rs=ps.executeQuery();
            while(rs.next())
            {
                femail=rs.getString("email");
            }
            rs.close();
            ps.close();
            con.close();
        }
        catch(Exception e)
        {
            System.out.println("Usignup.java: "+e);
        }
    }
    public String cemail()
    {
        return Usignup.femail;
    }
}
